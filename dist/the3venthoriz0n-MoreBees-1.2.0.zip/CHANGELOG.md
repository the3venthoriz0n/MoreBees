## v1.2.0
- Added unlimited sprint only while holding a hive

## v1.0.1
- Minor cleanup
- Removed unlimited batteries

## v1.0.0
- Initial Release