# More Bees
This is a mod for Lethal Company. It's exactly like it sounds; way way more bees (and some other stuff).

Please note, I have absolutely no clue how to mod games and this is currently a little broken. Fixes on the way.

Don't hesitate to report any "bugs" (pun intended) and if you really love it, [buy me a coffee!](https://www.buymeacoffee.com/the3venthoriz0n)

## Features
- Lots of Bees
- Unlimited Sprint
- A secret surprise


## Installation


### r2modman or Thunderstore Mod Manager

1. Click `Online`
2. Search for MoreBees
3. Download it / install it

### Manual (Not Recommended)
1. Go to the [thunderstore page](https://thunderstore.io/c/lethal-company/p/the3venthoriz0n/MoreBees)
2. Click `Manual Download`
3. Unzip files
4. Navigate to `the3venthoriz0n-MoreBees-x.x.x` and copy the MoreBees.dll file
5. Find your BepinEx installation's plugin folder, by default it would be in steamapps: `steamapps\common\Lethal Company\BepInEx\plugins`
6. Create a folder titled `the3venthoriz0n-MoreBees`
7. Paste the contents into that folder



## Future Plans
- Unlimited sprint only while holding a hive
- More bees can never hurt


